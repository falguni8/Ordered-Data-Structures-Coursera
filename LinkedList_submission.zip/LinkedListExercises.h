
/**
 * @file LinkedListExercises.h
 * University of Illinois CS 400, MOOC 2, Week 1: Linked List
 * Spring 2019
 *                        STUDENT STARTER FILE
 *
 * @author Eric Huber - University of Illinois staff
 *
**/

/********************************************************************
  Week 1: Linked List and Merge Sort Exercises

  There are two exercises in this file. Please read the code comments
  below and see the provided instructions PDF before you begin. The
  other provided code files in the starter zip also contain important
  comments and hints about how to approach this.

  This is the only file you can edit for the sake of grading! You can
  edit the other provided starter files for testing purposes, but the
  autograder will assume that this is the only file that has been edited
  by you, and the others will be replaced with the original intended
  versions at grading time.
 ********************************************************************/

// Prevent the header from being included more than once per cpp file
#pragma once

// It's good to put system headers first, so that if your own libraries
// cause conflicts, the compiler will most likely identify the problem
// as being in your own source code files, where it arises later.
#include <iostream>
#include <string>

#include "LinkedList.h"

/********************************************************************
  Exercise 1: insertOrdered

  This LinkedList member function assumes that the current contents
  of the list are already sorted in increasing order. The function
  takes as input a new data item to be inserted to the same list.
  The new data item should be inserted to the list in the correct
  position, so that you preserve the overall sorted state of the list.

  For example, if your LinkedList<int> contains:
  [1, 2, 8, 9]
  And the input is 7, then the list should be updated to contain:
  [1, 2, 7, 8, 9]

  To be more precise, a new node should be created on the heap, and
  it should be inserted in front of the earliest node in the list that
  contains a greater data element. If no such other node exists, then
  the new item should be placed at the end (the back of the list).

  Also, be sure to update the size_ member of the list appropriately.

  Your implementation of this function should not change the memory
  locations of the existing nodes. That is, you should not push or pop
  the existing elements of the list if it would change their address.
  (The member functions for push and pop will add a new node or delete
  one, so these operations would not leave the original node in place
  even if you recreated the node with equivalent data.) You should use
  pointers to connect your new node at the correct insertion location,
  being sure to adjust the list's head and tail pointers if necessary,
  as well as any prev or next pointers of adjacent nodes in the list.
  Remember: LinkedList is a doubly-linked list. That means each node
  also refers to the previous item in the list, not just the next item.

  A correct implementation of this function has O(n) time complexity
  for a list of length n. That is, in the worst case, you would
  traverse each element of the list some constant number of times.

  You can use "make test" followed by "./test" to check the correctness
  of your implementation, and then you can use "./test [bench]" to run
  some interesting benchmarks on the speed of your code.

 ********************************************************************/

template <typename T>
void LinkedList<T>::insertOrdered(const T& newData) {
    Node* newNode = new Node(newData);

    // Case 1: If the list is empty
    if (head_ == nullptr) {
        head_ = newNode;
        tail_ = newNode;
    } else {
        Node* current = head_;

        // Case 2: Insert at the beginning if the new data is less than or equal to the head data
        if (newData <= head_->data) {
            newNode->next = head_;
            head_->prev = newNode;
            head_ = newNode;
        } else {
            // Traverse the list to find the correct insertion point
            while (current->next != nullptr && current->next->data < newData) {
                current = current->next;
            }

            // Case 3: Insert in the middle or at the end
            newNode->next = current->next;
            newNode->prev = current;

            if (current->next != nullptr) {
                current->next->prev = newNode;
            } else {
                // Update tail if new node is inserted at the end
                tail_ = newNode;
            }

            current->next = newNode;
        }
    }

    // Increment the size of the list
    size_++;
}

template <typename T>
LinkedList<T> LinkedList<T>::merge(const LinkedList<T>& other) const {
  LinkedList<T> merged;

  // Pointers to traverse the left and right lists
  Node* leftCurrent = this->head_;
  Node* rightCurrent = other.head_;

  // While both lists have elements
  while (leftCurrent != nullptr && rightCurrent != nullptr) {
    if (leftCurrent->data <= rightCurrent->data) {
      merged.pushBack(leftCurrent->data);  // Add left node data to merged list
      leftCurrent = leftCurrent->next;     // Move to next node in left list
    } else {
      merged.pushBack(rightCurrent->data); // Add right node data to merged list
      rightCurrent = rightCurrent->next;   // Move to next node in right list
    }
  }

  // If there are remaining elements in the left list
  while (leftCurrent != nullptr) {
    merged.pushBack(leftCurrent->data);
    leftCurrent = leftCurrent->next;
  }

  // If there are remaining elements in the right list
  while (rightCurrent != nullptr) {
    merged.pushBack(rightCurrent->data);
    rightCurrent = rightCurrent->next;
  }

  return merged;
}
